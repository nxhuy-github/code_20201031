# Collect: Scraping to NFS (scraping_to_nfs)

## 1. General presentation

This app is a framework to collect data from websites (scraping process). This app is mainly based on scrapy (selenium and scrapy-splash might be needed in the future, to handle complex pages requiring JS rendering).

In general, you will use this app to download a full website (all pages + its contents) and store it in the datalake (BigQuery), before performing a content extraction for a specific use case (e.g. SEO ranking, price analysis, etc.). The content extraction is handled in a separate app **(mdm/app/content_parsing)**.

## 2. Usage

Build image:

```bash
docker build . -f Dockerfile -t scraping_to_nfs
```

Run:
```bash
docker run -e LOGGER_NAME=SCRAPING_TO_NFS \
-v /home/berriot-b/Documents/key/scraping:/app/key \
-e GOOGLE_APPLICATION_CREDENTIALS=/app/key/key.json \
-e EXPORT_DIRECTORY=/home/berriot-b/scraping \
-e EXTERNAL_RENDERING_URL=http://localhost:8080/?url= \
sqcraping_to_nfs \
USE_CASE DATE_REF MODE
```

* **USE_CASE**:
  * In the form of dataset_id.table_id
* **DATE_REF**:
  * Reference date for the crawl (format yyyymmdd) This parameter will usually be handled by Airflow. It corresponds to the first day of the week. It allows us to re-run a scraping process a few days later if the scraping failed, while keeping the same reference date.
* **MODE**:
  * (Default mode) scrapy_standalone: web pages will be loaded without Javascript rendering. This will work for basic websites with a low-level of anti-bot protection.
  * scrapy_external: use an external IP/URL address to handle the HTTP request. The external service can be a Javascript rendering service, to deal with websites with high-level of anti-bot protection. The external service can be hosted internally (e.g. on Kubernetes) or can be an external service. You will need to provide the URL address via the environment variable EXTERNAL_RENDERING_URL. NOTE: rendering the page will be much slower than scrapy_standalone (basic) mode.


## 3. Output format

This app will generate a JSON file:

* In a local folder on your system if running locally
* In a Kubernetes volume if running on Kubernetes (GKE or Minikube)

## 4. Spider file

A "spider" is a python class that crawls a website, scrapes interesting data from HTML source, finds and follows links to other pages.

**It contains crawling rules that are specific to your website:**

1. **What is the spider name?** Fill in the `name` attribute. **It should be the same as the BigQuery table name**.
2. **What is the starting page of my crawl?** Fill in `start_urls` attribute.
3. **What are the domains/sub-domains to crawl?** Fill in `allowed_domains` attribute.
4. **Do I have to restrict the crawling on a specific part of the website?** Fill in the `allow` argument of the `rules`. You can provide URLs in the form of regex.
5. **Which URLs (regex) should you avoid crawling?** Fill in  the `deny` argument of the `rules` attribute. You can provide URLs in the form of regex.
6. **How to tell Scrapy just to click on certain parts of the page?** Fill in the `restrict_xpaths` argument, in the form of xpath regexes.

For instance, for Ikea.fr:

* `name = 'ikea_fr'`
* `start_urls = ['https://www.ikea.com/fr/fr/']` Will start crawling on French Ikea Homepage.
* `allowed_domains = ['ikea.com']` Will only be restricted to ikea.com subdomains.
* `allow=(r'/fr/fr/')` Will only allow crawling on the French part of the website.
* `deny=(r'/\?', r'preview.ikea.com', r'%edit')` Will not follow some technical links.

NOTE: spiders will inherit from the "WebsiteDownloaderSpider" class, which is basically a generic spider that is able to download an entire website content.

## 5. Scrapy settings

Important scrapy settings are located in *resources/\<mode\>/settings.yaml*, for example:

* Which middleware to use to handle HTTP requests and responses?
* How pages should be stored (CSV file)?
* At which speed should we crawl the website?
* How to simulate a random user agent?
* Proxy settings?

To protect ourselves against website blocking, we should never crawl a website using our real IP address. We instead use a proxy that will perform our HTTP request with a randomly-assigned IP address at each request (e.g. Proxycrawl, which has a pool of around a million IP addresses).

Normally, you will not need to modify these settings, but only select between two modes:

* scrapy_standalone: use scrapy in basic mode, i.e. download webpages with internal scrapy downloader, without rendering the page. Will be significantly faster, but will not work on websites with advanced anti-bot protection systems.
* scrapy_external: by-pass scrapy built-in downloader with an external rendering service (e.g. Javascript rendering service with Selenium, mimicking a real Chrome browser). Will work on most websites even with anti-bot protection systems, but will be significantly lower.

## 7. Common issues

* **I get a '401 Unauthorized' when trying to launch a scraping.**
  * You must whitelist the IP address on Proxycrawl proxy before launching the app, by going on <proxycrawl.com>. This is automatically done within the **docker-entrypoint** file if you're using the Docker image.
  * There is only a limited amount of IP addresses than can be whitelisted (7 IP addresses as of Oct. 1, 2019). Sometimes you have to check this limit has not been reached when trying to whitelist a new IP address.

* **Scraping is very slow.**
  * Case 1: The website you are trying to scrape is probably very, very big. Also make sure to restrict URLs to some parts of the website only, or exclude technical pages (such as internal search pages, or fake URLs automatically created when selecting product filters on category pages).
  * Case 2: You're using an external JS rendering service which slows down the process.
  * Case 3: The Internet connection is sometimes slow from MDM office. Scraping on GCP is usually faster and more reliable.

## 8. Additional resources

### 8.1. Scrapy architecture

#### scrapy_standalone

```mermaid
graph TD;
classDef request fill:#f9f,stroke:#333;
Scrapy_Downloader-->|response|SPIDER;
SPIDER-->|request|Scrapy_Downloader;
SPIDER-->|scraped content|Item_Pipeline;
Item_Pipeline-->JSON_file
```

#### scrapy_external

```mermaid
graph TD;
classDef request fill:#f9f,stroke:#333;
EXTERNAL_SERVICE-->|response|Scrapy_Downloader;
Scrapy_Downloader-->|request|EXTERNAL_SERVICE;
Scrapy_Downloader-->|response|SPIDER;
SPIDER-->|request|Scrapy_Downloader;
SPIDER-->|scraped content|Item_Pipeline;
Item_Pipeline-->JSON_file
```

### 8.2. Useful links

* Scrapy library general documentation: <https://doc.scrapy.org/en/latest/>
* Scrapy settings reference: <https://doc.scrapy.org/en/latest/topics/settings.html#topics-settings-ref>
* Scrapy LinkExtractor reference (to design rules for your spiders): <https://doc.scrapy.org/en/latest/topics/link-extractors.html>
* Running Selenium on Docker: <https://github.com/SeleniumHQ/docker-selenium>
