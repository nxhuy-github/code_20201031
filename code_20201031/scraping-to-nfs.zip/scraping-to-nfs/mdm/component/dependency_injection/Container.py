from xml.dom import minidom
from mdm.component.dependency_injection.ServiceBuilder import ServiceBuilder
import json


class Container:
    def __init__(self):
        self.__instantiated_services = {}
        self.__service_builders = {}
        self.__json_parameters = {}

    def add_json_parameter_file(self, file_path):
        # type: (str) -> None
        """
        Add all parameters from a json file. The parameters are accessible in the following way:
        json_file.json
        {
            "database": {
                "port": 1231
            }
        }

        access in python
        container.get_parameter('database.port')
        """

        self.__json_parameters.update(json.load(open(file_path)))

    def add_xml_service_file(self, file_path):
        # type: (str) -> dict
        """
        Parse an xml service file, create and store service builders object to later build our services
        """

        xml = minidom.parse(file_path)

        for service in xml.getElementsByTagName("service"):
            service_builder = ServiceBuilder(service)
            self.__service_builders.update(
                {service_builder.get_service_id(): service_builder}
            )

        return self.__service_builders

    def get_parameter(self, parameter_key):
        # type: (str) -> str
        """
        Return a parameter value
        """

        parameter_path = parameter_key.split(".")
        parameter = self.__json_parameters
        for part in parameter_path:
            parameter = parameter[part]

        return parameter

    def add_parameter(self, parameter_name, parameter_value):
        # type: (str, str) -> None
        """
        Add a parameter to the parameters already in the container
        """

        self.__json_parameters.update({parameter_name: parameter_value})

    def get(self, service_id):
        """
        Return the instantiated service with the given service_id
        """

        if service_id in self.__instantiated_services:
            return self.__instantiated_services[service_id]

        service_builder = self.__service_builders[service_id]

        dependencies = service_builder.get_needed_services()
        if not dependencies:
            return self.__instantiate_service(service_id)

        for dependency in dependencies:
            service_builder.add_service(dependency, self.get(dependency))

        return self.__instantiate_service(service_id)

    def __instantiate_service(self, service_id):
        # type: (str) -> object
        """
        Build the service with the given service_id
        """

        service_builder = self.__service_builders[service_id]
        self.__instantiated_services.update(
            {service_id: service_builder.boot(self.__json_parameters)}
        )

        return self.__instantiated_services[service_id]
