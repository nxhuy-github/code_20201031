import importlib
import inspect
from xml.dom.minidom import Element
import re


class ServiceBuilder:
    """
    Class to parse a, xml_tag to create the associated service. It gather all the needed info from the xml and the
    parameters so that it can build the service when the boot method is called.
    """

    def __init__(self, xml_service_tag):
        self.__xml_service_tag = xml_service_tag
        self.__service_id = xml_service_tag.attributes["id"].value
        self.__needed_services = {}

        self.__is_direct_instantiation = True
        self.__booter = self.__get_booter(xml_service_tag)

        for child_node in xml_service_tag.childNodes:
            if child_node.nodeType != child_node.ELEMENT_NODE:
                continue

            tag_name = child_node.tagName
            if tag_name == "factory" or tag_name == "argument":
                self.__store_needed_services(child_node)

            if tag_name == "factory":
                self.__is_direct_instantiation = False
                self.__booter = self.__get_booter(child_node)

            for call_argument in child_node.childNodes:
                if call_argument.nodeType != call_argument.ELEMENT_NODE:
                    continue

                self.__store_needed_services(call_argument)

    @staticmethod
    def __get_booter(xml_argument):
        if (
            "module" in xml_argument.attributes.keys()
            and "class" in xml_argument.attributes.keys()
        ):
            module_name = xml_argument.attributes["module"].value
            class_name = xml_argument.attributes["class"].value
            object_module = importlib.import_module(module_name)

            return getattr(object_module, class_name)

        if "service" in xml_argument.attributes.keys():
            return xml_argument.attributes["service"].value

        return None

    def __store_needed_services(self, xml_argument):
        # type: (Element) -> None
        """
        Saves the dependencies (other services) needed for this particular service
        """

        if "type" in xml_argument.attributes.keys():
            self.__needed_services.update({xml_argument.attributes["id"].value: None})

        if "service" in xml_argument.attributes.keys():
            self.__needed_services.update(
                {xml_argument.attributes["service"].value: None}
            )

    def add_service(self, service_id, instantiated_service):
        self.__needed_services[service_id] = instantiated_service

    def get_needed_services(self):
        return self.__needed_services.keys()

    def boot(self, parameters):
        # type: (dict) -> object
        """
        Method called when the service is actually needed by the container (when container get method is called)
        """

        instance = None
        constructor_arguments = []
        method_name = "__init__"

        call_methods = {}
        for child_node in self.__xml_service_tag.childNodes:
            if child_node.nodeType != child_node.ELEMENT_NODE:
                continue
            if child_node.tagName == "argument":  # init
                constructor_arguments.append(
                    self.__read_xml_arguments(child_node, parameters)
                )

            if child_node.tagName == "factory":  # factory call
                method_name = child_node.attributes["method"].value
                for call_argument in child_node.childNodes:
                    if (
                        call_argument.nodeType == call_argument.ELEMENT_NODE
                        and call_argument.tagName == "argument"
                    ):
                        constructor_arguments.append(
                            self.__read_xml_arguments(call_argument, parameters)
                        )

            if child_node.tagName == "call":  # standard call
                call_name = child_node.attributes["method"].value
                number_of_calls = []
                method_arguments = []
                for call_argument in child_node.childNodes:
                    if (
                        call_argument.nodeType == call_argument.ELEMENT_NODE
                        and call_argument.tagName == "argument"
                    ):
                        method_arguments.append(
                            self.__read_xml_arguments(call_argument, parameters)
                        )

                if call_name in call_methods:
                    number_of_calls = call_methods[call_name]

                number_of_calls.append(method_arguments)

                call_methods.update({call_name: number_of_calls})

        if method_name == "__init__":
            instance = self.__booter(*constructor_arguments)

        elif not self.__is_direct_instantiation:
            factory = (
                self.__booter()
                if inspect.isclass(self.__booter)
                else self.__needed_services[self.__booter]
            )
            instance = getattr(factory, method_name)(*tuple(constructor_arguments))

        for method_name in call_methods:
            number_of_calls = call_methods[method_name]
            for arguments in number_of_calls:
                getattr(instance, method_name)(*tuple(arguments))

        return instance

    def __read_xml_arguments(self, xml_argument, parameters):
        if xml_argument.childNodes:
            dirty_arg = xml_argument.childNodes[0].nodeValue
        else:
            dirty_arg = xml_argument.attributes["id"].value

        dirty_arg = dirty_arg.strip(' "\t\n\r')

        if "%" in dirty_arg:
            arguments = re.findall("%(.*?)%", dirty_arg)
            for argument in arguments:
                keys = argument.split(".")
                value = parameters
                for key in keys:
                    value = value[key]
                if isinstance(value, str):
                    dirty_arg = dirty_arg.replace(
                        "%{argument}%".format(argument=argument), str(value)
                    )
                else:
                    dirty_arg = value

        if isinstance(dirty_arg, list):
            cleaned_arg = []
            for arg in dirty_arg:
                cleaned_arg.append(self.__get_typed_arg(arg))
            return cleaned_arg

        if not isinstance(dirty_arg, dict) and dirty_arg in self.__needed_services:
            dirty_arg = self.__needed_services[dirty_arg]

        return ServiceBuilder.__get_typed_arg(dirty_arg)

    @staticmethod
    def __get_typed_arg(untyped_arg):
        if isinstance(untyped_arg, str):
            try:
                return int(
                    untyped_arg
                )  # to try casting parameters as integer if possible
            except ValueError:
                return str(untyped_arg)  # to avoid having unicode instead of str
        return untyped_arg

    def get_service_id(self):
        return self.__service_id
