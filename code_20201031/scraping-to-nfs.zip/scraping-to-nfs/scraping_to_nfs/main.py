import argparse
import os
from sys import exit
from dotenv import load_dotenv

import logging
from scrapy.utils import log
from google.cloud import logging as glogging

from mdm.component.dependency_injection.Container import Container


if __name__ == "__main__":
    # Load python arguments
    parser = argparse.ArgumentParser(
        description="Collect from web scraping scripts to local storage/NFS"
    )

    parser.add_argument(
        "use_case", type=str, help="Use case name (format: dataset_id.table_id)"
    )

    parser.add_argument("date_ref", type=str, help="Reference date (format: YYYYMMDD)")

    parser.add_argument("mode", type=str, nargs="?", default="scrapy_standalone")

    args = parser.parse_args()
    data_set_id, table_id = args.use_case.split(".")
    date_ref = args.date_ref
    mode = args.mode

    export_directory = os.path.join(os.getenv("EXPORT_DIRECTORY", "/nfs"), data_set_id)
    if not os.path.exists(export_directory):
        os.makedirs(export_directory)

    external_rendering_url = os.getenv(
        "EXTERNAL_RENDERING_URL", "http://localhost:8080/?url="
    )

    # Logging
    log.configure_logging(install_root_handler=False)

    handler = glogging.handlers.CloudLoggingHandler(
        glogging.Client(project=os.getenv("PROJECT_ID", "mdm-data-preprod")),
        name=os.getenv("LOGGER_NAME"),
    )
    handler.setLevel(logging.INFO)
    logger = logging.getLogger()
    logger.addHandler(handler)

    # Container dependencies
    container = Container()
    container.add_xml_service_file("scraping_to_nfs/resources/services.xml")
    container.add_parameter("mode", mode)
    container.add_parameter("export_directory", export_directory)
    container.add_parameter("table_id", table_id)
    container.add_parameter("date_ref", date_ref)
    container.add_parameter("external_rendering_url", external_rendering_url)

    # Main process
    collector = container.get("crawler_process")
    collector.crawl(table_id, date_ref=date_ref)
    r = collector.start()
    exit(r)
