from jinja2 import Environment, Template, BaseLoader
import yaml
from scrapy.crawler import Settings
from scrapy.crawler import CrawlerProcess


class SettingsFactory:
    """
    Factory used to setup scrapy settings
    """

    @staticmethod
    def get_settings(yaml_file, export_file_path, external_rendering_url):
        """
        Return scrapy settings
        
        Parameters
        ----------
        yaml_file (str): path to scrapy settings template file (.yaml)
        export_file_path (str): path to file to export scrapy results.
        external_rendering_url (str): URL address of External Downloader to use with scrapy (if used).
        Returns
        -------
        scrapy.crawler.Settings
            settings
        """
        with open(yaml_file, "r") as f:
            template = Environment(loader=BaseLoader()).from_string(f.read())

        settings_yaml = template.render(
            export_file_path=export_file_path,
            external_rendering_url=external_rendering_url,
        )
        return Settings(yaml.load(settings_yaml, Loader=yaml.FullLoader))
