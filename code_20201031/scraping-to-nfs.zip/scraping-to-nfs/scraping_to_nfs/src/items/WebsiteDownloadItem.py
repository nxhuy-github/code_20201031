from scrapy import Item, Field
from scrapy.loader.processors import TakeFirst


class WebsiteDownloadItem(Item):
    """
    Website pages representation for CSV/JSON export
    """

    date_ref = Field(output_processor=TakeFirst())
    date_crawl = Field(output_processor=TakeFirst())
    site_url = Field(output_processor=TakeFirst())
    request_meta = Field(output_processor=TakeFirst())
    response_url = Field(output_processor=TakeFirst())
    response_status = Field(output_processor=TakeFirst())
    response_meta = Field(output_processor=TakeFirst())
    response_headers = Field(output_processor=TakeFirst())
    response_body = Field(output_processor=TakeFirst())

    def __str__(self):
        """
        Overrides str representation of object in scrapy log (DEBUG level)
        """

        return "[Item scraped]"
