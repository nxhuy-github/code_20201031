from scrapy.http import HtmlResponse
from scrapy.utils.response import get_meta_refresh
from scrapy.downloadermiddlewares.redirect import BaseRedirectMiddleware


class CustomMetaRefreshMiddleware(BaseRedirectMiddleware):
    """
    Modifies scrapy.MetaRefreshMiddleware to be able to list all redirections on a website using Scrapy.
    Instead of blocking the 3XX response, it passes the response to the spider 
    and generates a new HTTP request based on the redirection link to follow.
    """

    enabled_setting = "METAREFRESH_ENABLED"

    def __init__(self, settings):
        super(CustomMetaRefreshMiddleware, self).__init__(settings)
        self._maxdelay = settings.getint(
            "REDIRECT_MAX_METAREFRESH_DELAY", settings.getint("METAREFRESH_MAXDELAY")
        )

    def process_response(self, request, response, spider):
        if (
            request.meta.get("dont_redirect", False)
            or request.method == "HEAD"
            or not isinstance(response, HtmlResponse)
        ):
            return response

        interval, url = get_meta_refresh(response)
        if url and interval < self._maxdelay:
            redirected = self._redirect_request_using_get(request, url)
            # Generate a new request for the engine. The original response will still be passed to spider.
            spider.crawler.engine.crawl(
                self._redirect(redirected, request, spider, "meta refresh"), spider
            )
        return response
