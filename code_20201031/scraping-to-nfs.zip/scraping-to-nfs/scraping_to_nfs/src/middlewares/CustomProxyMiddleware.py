from w3lib.http import basic_auth_header
from urllib.parse import urlparse


class CustomProxyMiddleware(object):
    """
    Adds to HTTP request metadata the connection information to a proxy service.
    """

    def __init__(self, settings):
        self.__proxy_host = settings.get("PROXY_HOST")
        self.__proxy_port = settings.get("PROXY_PORT")
        self.__proxy_user = settings.get("PROXY_USER")
        self.__proxy_password = settings.get("PROXY_PASSWORD")

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings)

    def process_request(self, request, spider):
        request.meta["proxy"] = "{scheme}://{host}:{port}".format(
            scheme=urlparse(request.url).scheme,
            host=self.__proxy_host,
            port=self.__proxy_port,
        )
        if self.__proxy_user and self.__proxy_password:
            request.headers["Proxy-Authorization"] = basic_auth_header(
                self.__proxy_user, self.__proxy_password
            )
