import re


class ExternalDownloaderMiddleware(object):
    """
    A Middleware to overwrite request URL with external downloader endpoint.
    (External service to handle JS rendering for instance)
    """

    def __init__(self, settings):
        self.__external_service_addr = settings.get("EXTERNAL_RENDERING_URL")

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler.settings)

    def process_request(self, request, spider):
        """
        Overwrites request URL with external downloader endpoint 
        before sending request to the external downloader.
        If URL is already overwritten, do not overwrite (to avoid an infinite loop because of Scrapy architecture)
        """
        if re.search(re.escape(self.__external_service_addr), request.url):
            return None
        return request.replace(url=self.__external_service_addr + request.url)

    def process_response(self, request, response, spider):
        """
        Removes the external downloader endpoint from the response URL
        before passing the response to the spider.
        """
        return response.replace(
            url=response.url.replace(self.__external_service_addr, "")
        )

    def spider_opened(self, spider):
        pass

    def spider_closed(self, spider):
        pass
