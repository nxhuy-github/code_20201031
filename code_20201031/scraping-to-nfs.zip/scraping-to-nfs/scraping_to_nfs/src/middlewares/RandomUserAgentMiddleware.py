from scrapy import signals
import random
from scrapy.downloadermiddlewares.useragent import UserAgentMiddleware


class RandomUserAgentMiddleware(UserAgentMiddleware):
    """
    Sets a random User-Agent for each request
    from a specified list (user_agents.txt)
    """

    def __init__(self, settings):
        super(RandomUserAgentMiddleware, self).__init__()
        user_agent_list_file = settings.get("USER_AGENT_LIST")
        with open(user_agent_list_file, "r") as f:
            self.__user_agent_list = [line.strip() for line in f.readlines()]

    @classmethod
    def from_crawler(cls, crawler):
        obj = cls(crawler.settings)
        crawler.signals.connect(obj.spider_opened, signal=signals.spider_opened)
        return obj

    def process_request(self, request, spider):
        user_agent = random.choice(self.__user_agent_list)
        if user_agent:
            request.headers.setdefault("User-Agent", user_agent)
