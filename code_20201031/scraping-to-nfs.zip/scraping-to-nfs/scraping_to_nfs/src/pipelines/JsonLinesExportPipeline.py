from scrapy.exporters import JsonLinesItemExporter


class JsonLinesExportPipeline(object):
    """
    Pipeline to write scrapy Items to a JSON Newline file.
    """

    @classmethod
    def from_crawler(cls, crawler):
        export_file_path = crawler.settings.get("EXPORT_FILE_PATH")
        return cls(export_file_path)

    def __init__(self, export_file_path):
        self.__export_file_path = export_file_path

    def open_spider(self, spider):
        self.file = open(self.__export_file_path, "wb")
        self.exporter = JsonLinesItemExporter(
            self.file, encoding="utf-8", ensure_ascii=False
        )
        self.exporter.start_exporting()

    def close_spider(self, spider):
        self.exporter.finish_exporting()
        self.file.close()

    def process_item(self, item, spider):
        self.exporter.export_item(item)
        return item
