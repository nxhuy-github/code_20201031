# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.WebsiteDownloaderSpider import WebsiteDownloaderSpider


class ButFrSpider(WebsiteDownloaderSpider):
    """
    But france spider
    
    Parameters
    ----------
    WebsiteDownloaderSpider : class
        Standard Spider
    
    """

    name = "but_fr"

    # Specific crawling rules for this website
    start_urls = ["https://www.but.fr"]
    allowed_domains = ["www.but.fr"]
    rules = (
        Rule(
            LinkExtractor(
                allow=(
                    r"index-[a-d][0-9+]",  # Category pages
                    r"\/produits\/",  # Product pages
                ),
                deny=(
                    r"\/Common\/Search",  # Internal Search Engine
                    r"\/loisirs-sport-bagagerie\/",  # Specific categories
                    r"\/cuisine\/evier-et-robinet",
                    r"\/electromenager\/",
                    r"\/beaute-bien-etre\/",
                    r"\/themes\/",
                    r"\/tv-image-et-son\/",
                ),
                restrict_xpaths=(
                    "//*[@id='bloc_menu']",  # Header menu
                    "//div[@class='fil_ariane']",  # Breadcrumb
                    "//div[@class='content-page-liste']",  # Main section of category pages
                ),
            ),
            callback="parse_page",
            process_links="exclude_no_follow_links",
            follow=True,
        ),
    )
