# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.WebsiteDownloaderSpider import WebsiteDownloaderSpider


class CasaFrSpider(WebsiteDownloaderSpider):
    """
    Casa france spider
    
    Parameters
    ----------
    WebsiteDownloaderSpider : class
        Standard Spider
    
    """

    name = "casa_fr"

    # Specific crawling rules for this website
    start_urls = ["https://fr.casashops.com/fr"]
    allowed_domains = ["fr.casashops.com"]
    rules = (
        Rule(
            LinkExtractor(
                allow=(r"\/fr\/"),  # FR website only
                deny=(
                    r"_fk_",  # Exclude filter selection on category pages
                    r"\?sort=",
                    r"envoyez-un-message",
                    r"\/fr\/.+\/.+\/.+\/.+",  # Prevent infinite paths
                ),
                restrict_xpaths=(
                    "//a[not(contains(@class, 'is-disabled'))]"  # Prevent infinite pagination (on rel="next")
                ),
            ),
            callback="parse_page",
            process_links="exclude_no_follow_links",
            follow=True,
        ),
    )
