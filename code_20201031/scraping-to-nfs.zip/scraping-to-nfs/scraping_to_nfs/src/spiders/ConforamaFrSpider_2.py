# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.WebsiteDownloaderSpider import WebsiteDownloaderSpider


class ConforamaFrSpider(WebsiteDownloaderSpider):
    """
    Conforama france spider
    
    Parameters
    ----------
    WebsiteDownloaderSpider : class
        Standard Spider

    """

    name = "conforama_fr_lot_2"

    # Specific crawling rules for this website
    start_urls = [
        "https://www.conforama.fr/decoration-textile/c/05",
        "https://www.conforama.fr/enfant-bebe/c/06",
        "https://www.conforama.fr/tv-son-multimedia/c/08",
        "https://www.conforama.fr/jardin-loisirs-sport/c/09",
    ]
    allowed_domains = ["www.conforama.fr"]
    rules = (
        Rule(
            LinkExtractor(
                allow=(
                    r"\/decoration-textile\/",  # Specific category pages
                    r"\/enfant-bebe\/",
                    r"\/tv-son-multimedia\/",
                    r"\/jardin-loisirs-sport\/",
                    r"\/p\/",  # Product pages
                ),
                deny=(
                    # r'\/p\/[A-Z][0-9]+', # Every product SKU starting with a letter (= marketplace, not Conforama)
                    r"\/recherche-conforama\/",  # Internal search engine
                    # r'\/marchand\/', # Third-party merchant pages
                    r"\/les-marques-conforama\/",  # Third-party brand pages
                    r"\/gros-electromenager\/",  # Specific categories
                    r"\/petit-electromenager\/",
                    r"\/jardin-loisirs-sport\/(?!mobilier-de-jardin|amenagement-et-decoration-jardin)",  # Specific category except 2 subcategories
                    r"\/tv-son-multimedia\/(?!tv-television\/meuble-et-support-tv)",  # Specific category except 1 subcategory
                    r"\/enfant-bebe\/(?!chambre-enfant|decoration-chambre-enfant|chambre-bebe)",  # Specific category except 3 subcategories
                    r"\/cuisine-salle-de-bain\/element-de-cuisine\/evier-et-mitigeur",  # Specific subcategories
                    r"\/cuisine-salle-de-bain\/element-de-cuisine\/accessoires-de-cuisine",
                    r"\/cuisine-salle-de-bain\/meuble-de-salle-de-bain\/colonne-et-paroi-de-douche",
                    r"\/cuisine-salle-de-bain\/meuble-de-salle-de-bain\/vasque-et-lavabo",
                    r"\/cuisine-salle-de-bain\/meuble-de-salle-de-bain\/baignoire-et-douche-hydromassantes",
                    r"[Pp]opin|productavailable|update-store|miniFiche",  # pop-ins, technical links, recommendation engine links
                    r"\?[^p|l]|&p",  # Deny all URL parameters except ?p for pagination and ?lat for store detail pages
                    r"\/([pc]|marchand|services|guide-achat)\/.*\/c\/",  # Complex navigation patterns (redirections to category pages from higher-depth pages)
                ),
                restrict_xpaths=(
                    "//*[contains(@class,'sitemap')]",  # Links from site map
                    "//*[contains(@class,'univers')]",  # content of univers pages
                    "//*[contains(@id,'contentSegment')]",  # content of category pages
                ),
            ),
            callback="parse_page",
            process_links="exclude_no_follow_links",
            follow=True,
        ),
    )
