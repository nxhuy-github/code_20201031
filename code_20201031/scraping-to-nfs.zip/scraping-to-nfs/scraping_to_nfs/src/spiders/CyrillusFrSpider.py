# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.WebsiteDownloaderSpider import WebsiteDownloaderSpider


class CyrillusFrSpider(WebsiteDownloaderSpider):
    """
    Cyrillus france spider
    
    Parameters
    ----------
    WebsiteDownloaderSpider : class
        Standard Spider
    
    """

    name = "cyrillus_fr"

    # Specific crawling rules for this website
    start_urls = ["https://www.cyrillus.com/fr/maison.htm"]
    allowed_domains = ["www.cyrillus.com"]
    rules = (
        Rule(
            LinkExtractor(
                allow=(
                    r"\/fr\/maison",  # allow FR website on maison category only
                    r"\?ProductId=",  # allow product pages
                ),
                deny=(
                    r"\/Taille=",  # Exclude filter selection on category pages
                    r"\/couleurs=",
                    r"\/Prix=",
                    r"\/Demarque=",
                    r"\?Prix",
                ),
                restrict_xpaths=(
                    "//*[@id='main']",  # Select links from main part of category page only
                    "//*[@id='header']",  # Select links from header part only
                ),
            ),
            callback="parse_page",
            process_links="exclude_no_follow_links",
            follow=True,
        ),
    )
