# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.WebsiteDownloaderSpider import WebsiteDownloaderSpider


class DecoFrSpider(WebsiteDownloaderSpider):
    """
    Deco france spider
    
    Parameters
    ----------
    WebsiteDownloaderSpider : class
        Standard Spider
    
    """

    name = "deco_fr"

    # Specific crawling rules for this website
    start_urls = ["https://www.deco.fr"]
    allowed_domains = ["www.deco.fr"]
    rules = (
        Rule(
            LinkExtractor(allow=(), deny=()),
            callback="parse_page",
            process_links="exclude_no_follow_links",
            follow=True,
        ),
    )
