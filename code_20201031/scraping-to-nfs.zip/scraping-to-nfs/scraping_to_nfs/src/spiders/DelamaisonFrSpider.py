# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.WebsiteDownloaderSpider import WebsiteDownloaderSpider


class DelamaisonFrSpider(WebsiteDownloaderSpider):
    """
    De la maison france spider
    
    Parameters
    ----------
    WebsiteDownloaderSpider : class
        Standard Spider
    
    """

    name = "delamaison_fr"

    # Specific crawling rules for this website
    start_urls = ["https://www.delamaison.fr"]
    allowed_domains = ["delamaison.fr"]
    rules = (
        Rule(
            LinkExtractor(
                allow=(),
                deny=(
                    r"/login/referer/",  # Login page
                    r"/sendfriend/",  # Send to a friend link
                    r"product_list_order"  # Sort filter on category page
                    # r'\?[^p]|price=|product_list_order=', # Every URL parameter except ?p for pagination
                    r"tel:",  # Links to phone numbers
                    r"catalogsearch",  # Internal search engine pages
                    r"contact-sc",
                ),
                # Faulty page
                restrict_xpaths=(
                    "//*[contains(@class,'nav-sections')]",  # Header
                    "//*[contains(@class, 'column main')]",  # Main content of category page
                ),
            ),
            callback="parse_page",
            process_links="exclude_no_follow_links",
            follow=True,
        ),
    )
