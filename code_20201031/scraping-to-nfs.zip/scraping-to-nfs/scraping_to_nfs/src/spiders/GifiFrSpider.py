# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.WebsiteDownloaderSpider import WebsiteDownloaderSpider


class GifiFrSpider(WebsiteDownloaderSpider):
    """
    Gifi france spider
    
    Parameters
    ----------
    WebsiteDownloaderSpider : class
        Standard Spider
    
    """

    name = "gifi_fr"

    # Specific crawling rules for this website
    start_urls = ["https://www.gifi.fr"]
    allowed_domains = ["www.gifi.fr"]
    rules = (
        Rule(
            LinkExtractor(
                allow=(),
                deny=(
                    r"jardin-plein-air\/amenagement-jardin",  # Exclude specific subcategories
                    r"jardin-plein-air\/piscine-spa",
                    r"jardin-plein-air\/camping",
                    r"jardin-plein-air\/plage",
                    r"cuisine-art-de-la-table\/electromenager",
                    r"entretien-rangement\/entretien",
                    r"entretien-rangement\/entretien-linge",
                    r"entretien-rangement\/bricolage",
                    r"entretien-rangement\/auto-et-velo",
                    r"entretien-rangement\/securite",
                    r"bien-etre-loisirs",
                    r"fetes-et-evenements",
                    r"deco-a-parsemer",
                    r"jouets\/jouets-enfant",
                    r"jouets\/jeux-creatifs",
                    r"jouets\/jeux-de-concentration",
                    r"jouets\/jeux-de-plein-air",
                    r"animalerie\/litiere-toilettage",
                ),
                restrict_xpaths=(
                    "//*[@class='category-products']",  # Select links from main part of category page only
                    "//*[@class='nav-container']",  # Select links from header part only
                ),
            ),
            callback="parse_page",
            process_links="exclude_no_follow_links",
            follow=True,
        ),
    )
