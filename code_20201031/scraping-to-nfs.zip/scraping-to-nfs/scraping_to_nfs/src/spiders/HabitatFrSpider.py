# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.WebsiteDownloaderSpider import WebsiteDownloaderSpider


class HabitatFrSpider(WebsiteDownloaderSpider):
    """
    Habitat france spider
    
    Parameters
    ----------
    WebsiteDownloaderSpider : class
        Standard Spider
    
    """

    name = "habitat_fr"

    # Specific crawling rules for this website
    start_urls = ["https://www.habitat.fr"]
    allowed_domains = ["www.habitat.fr"]
    rules = (
        Rule(
            LinkExtractor(
                allow=(), deny=(r"/sc/")
            ),  # Filter selection on category pages
            callback="parse_page",
            process_links="exclude_no_follow_links",
            follow=True,
        ),
    )
