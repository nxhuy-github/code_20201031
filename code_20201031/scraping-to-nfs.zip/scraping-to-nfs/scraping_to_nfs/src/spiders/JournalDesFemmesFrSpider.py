# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.WebsiteDownloaderSpider import WebsiteDownloaderSpider


class JournalDesFemmesFrSpider(WebsiteDownloaderSpider):
    """
    Journal des femmes france spider
    
    Parameters
    ----------
    WebsiteDownloaderSpider : class
        Standard Spider
    
    """

    name = "journal_des_femmes_fr"

    # Specific crawling rules for this website
    start_urls = ["https://deco.journaldesfemmes.fr"]
    allowed_domains = ["deco.journaldesfemmes.fr"]
    rules = (
        Rule(
            LinkExtractor(allow=(), deny=(r"\/forum\/")),
            callback="parse_page",
            process_links="exclude_no_follow_links",
            follow=True,
        ),
    )
