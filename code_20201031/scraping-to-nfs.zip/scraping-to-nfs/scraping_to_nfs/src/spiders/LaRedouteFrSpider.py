# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.WebsiteDownloaderSpider import WebsiteDownloaderSpider


class LaRedouteFrSpider(WebsiteDownloaderSpider):
    """
    La Redoute France spider
    
    Parameters
    ----------
    WebsiteDownloaderSpider : class
        Standard Spider
    
    """

    name = "laredoute_fr"

    # Specific crawling rules for this website
    start_urls = ["https://www.laredoute.fr"]
    allowed_domains = ["laredoute.fr"]
    rules = (
        Rule(
            LinkExtractor(
                allow=(
                    r"pplp\/100\/84100",  # Meuble & Deco category
                    r"pplp\/100\/cat-84100",
                    r"pplp\/100\/75363",  # Linge de maison category
                    r"pplp\/100\/cat-75363",
                    r"ppdp\/prod",  # product pages
                ),
                restrict_xpaths=(
                    "//*[@class='menu-container']",  # Select links from header part only
                    "//*[@class='categoriestree']",  # Select links from left panel of univers pages
                    "//*[@class='guided-nav']",  # Select links from left panel of category pages
                    "//*[@id='productList']",  # Select links from main product listing
                    "//*[contains(@class,'pl-pagination')]",  # Select pagination links
                ),
            ),
            callback="parse_page",
            process_links="exclude_no_follow_links",
            follow=True,
        ),
    )
