# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.WebsiteDownloaderSpider import WebsiteDownloaderSpider


class LeroyMerlinFrSpider(WebsiteDownloaderSpider):
    """
    Leroy Merlin france spider
    
    Parameters
    ----------
    WebsiteDownloaderSpider : class
        Standard Spider
    
    """

    name = "leroy_merlin_fr"

    # Specific crawling rules for this website
    start_urls = ["https://www.leroymerlin.fr"]
    allowed_domains = ["www.leroymerlin.fr"]
    rules = (
        Rule(
            LinkExtractor(
                allow=(
                    # Specific subcategories
                    r"\/p\/produits\/terrasse-jardin\/salon-de-jardin",
                    r"\/p\/produits\/terrasse-jardin\/fontaine-bassin",
                    r"\/p\/produits\/salle-de-bains\/meuble-de-salle-de-bains",
                    r"\/p\/produits\/salle-de-bains\/accessoires",
                    r"\/p\/produits\/salle-de-bains\/rangement",
                    r"\/p\/produits\/cuisine\/meuble",
                    r"\/p\/produits\/cuisine\/plan-de-travail",
                    r"\/p\/produits\/cuisine\/poubelle",
                    r"\/p\/produits\/rangement",
                    r"\/p\/produits\/decoration",
                    # Product pages
                    r"e[0-9]+",
                ),
                deny=(r"#avis"),
                restrict_xpaths=(
                    "//*[@class='nav-layer-container']",  # Follow links from header overlay menu
                    "//*[contains(@class,'fil-ariane')]",  # Follow links in breadcrumb
                    "//*[contains(@class,'pagination')]",  # Follow pagination links
                    "//*[contains(@class, 'container-product')]",  # Follow product links
                ),
            ),
            callback="parse_page",
            process_links="exclude_no_follow_links",
            follow=True,
        ),
    )
