# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.WebsiteDownloaderSpider import WebsiteDownloaderSpider


class MdmBaseSpider(WebsiteDownloaderSpider):
    """
    Maisons du monde Generic Spider. All spiders for MDM websites will derive from this base spider.
    
    Parameters
    ----------
    WebsiteDownloaderSpider : class
        Standard Spider
    
    """

    @staticmethod
    def set_start_urls(country, language):
        """
        Constructs start_url class attribute for a Mdm website spider.
        Args:
            country (str): country of desired MDM market x language.
            language (str): language of desired MDM market x language.
        returns:
            list : list of strings of start URLS.
        """
        start_urls = [
            "https://www.maisonsdumonde.com/{country}/{language}".format(
                country=country, language=language
            )
        ]
        return start_urls

    @staticmethod
    def set_allowed_domains():
        """
        Constructs allowed_domains class attribute for a Mdm website spider.
        returns:
            list : list of strings of allowed domains.
        """
        allowed_domains = ["maisonsdumonde.com"]
        return allowed_domains

    @staticmethod
    def set_rules(country, language):
        """
        Constructs rules class attribute for a Mdm website spider.
        returns:
            (Rule): tuple of Rules.
        """
        rules = (
            Rule(
                LinkExtractor(
                    allow=(
                        r"/{country}/{language}/".format(
                            country=country, language=language
                        )
                    )
                ),  # Pages undder a specific combination of country + language
                callback="parse_page",
                process_links="exclude_no_follow_links",
                follow=True,
            ),
        )
        return rules
