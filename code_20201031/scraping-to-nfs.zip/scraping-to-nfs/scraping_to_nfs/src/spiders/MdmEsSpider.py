# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.MdmBaseSpider import MdmBaseSpider


class MdmEsSpider(MdmBaseSpider):
    """
    Maisons du monde ES spider
    
    Parameters
    ----------
    MdmBaseSpider: class
        Base class for all MDM websites.
    
    """

    name = "mdm_es"

    # Specific crawling rules for this website
    country = "ES"
    language = "es"

    start_urls = MdmBaseSpider.set_start_urls(country, language)
    allowed_domains = MdmBaseSpider.set_allowed_domains()
    rules = MdmBaseSpider.set_rules(country, language)
