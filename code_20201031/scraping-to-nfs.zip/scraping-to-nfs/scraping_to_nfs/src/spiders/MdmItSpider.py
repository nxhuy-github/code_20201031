# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.MdmBaseSpider import MdmBaseSpider


class MdmItSpider(MdmBaseSpider):
    """
    Maisons du monde DE spider
    
    Parameters
    ----------
    MdmBaseSpider: class
        Base class for all MDM websites.
    
    """

    name = "mdm_it"

    # Specific crawling rules for this website
    country = "IT"
    language = "it"

    start_urls = MdmBaseSpider.set_start_urls(country, language)
    allowed_domains = MdmBaseSpider.set_allowed_domains()
    rules = MdmBaseSpider.set_rules(country, language)
