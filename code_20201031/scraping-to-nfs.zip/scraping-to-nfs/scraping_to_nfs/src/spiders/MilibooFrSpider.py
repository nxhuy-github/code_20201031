# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.WebsiteDownloaderSpider import WebsiteDownloaderSpider


class MilibooFrSpider(WebsiteDownloaderSpider):
    name = "miliboo_fr"

    # Specific crawling rules for this website
    start_urls = ["https://www.miliboo.com"]
    allowed_domains = ["www.miliboo.com"]
    rules = (
        Rule(
            LinkExtractor(
                allow=(),
                deny=(
                    r"dev\.www\.miliboo" r"\?params=",  # Preprod websites
                    r"PageSpeed=",
                    r"filter[a-zA-Z]+=",  # URL parameters for filters
                    r"recherche",  # Search pages and URL parameters
                    r"mon-panier",
                    r"uptoyou",
                    r"\?vote",
                ),
                restrict_xpaths=(
                    "//*[contains(@class,'m-categorie-liste-produits')]",  # Extract links from Header and product list only
                    "//*[contains(@class,'m-menubar')]",
                ),
            ),
            callback="parse_page",
            process_links="exclude_no_follow_links",
            follow=True,
        ),
    )
