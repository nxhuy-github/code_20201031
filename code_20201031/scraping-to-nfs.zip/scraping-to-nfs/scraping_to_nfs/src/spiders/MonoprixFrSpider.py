# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.WebsiteDownloaderSpider import WebsiteDownloaderSpider


class MonoprixFrSpider(WebsiteDownloaderSpider):
    """
    Monoprix Maison france spider
    
    Parameters
    ----------
    WebsiteDownloaderSpider : class
        Standard Spider
    
    """

    name = "monoprix_fr"

    # Specific crawling rules for this website
    start_urls = ["https://www.monoprix.fr/maison"]
    allowed_domains = ["www.monoprix.fr"]
    rules = (
        Rule(
            LinkExtractor(
                allow=(
                    r"[0-9]+-p",  # allow product pages
                    r"\/maison\/",  # Allow specific categories
                ),
                deny=(
                    r"\?Ns",  # Exclude filter selection on category pages
                    r"\/f[a-zA-Z]\/",
                    r"\/courses-en-ligne",  # Exclude specific categories
                    r"\/mode",
                    r"\/maison\/electro-menager",
                    r"\/maison\/high-tech",
                ),
            ),
            callback="parse_page",
            process_links="exclude_no_follow_links",
            follow=True,
        ),
    )
