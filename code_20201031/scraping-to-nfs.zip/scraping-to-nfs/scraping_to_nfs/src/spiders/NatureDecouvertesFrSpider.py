# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.WebsiteDownloaderSpider import WebsiteDownloaderSpider


class NatureDecouvertesFrSpider(WebsiteDownloaderSpider):
    """
    Nature & Decouvertes france spider
    
    Parameters
    ----------
    WebsiteDownloaderSpider : class
        Standard Spider
    
    """

    name = "nature_decouvertes_fr"

    # Specific crawling rules for this website
    start_urls = ["https://www.natureetdecouvertes.com/"]
    allowed_domains = ["www.natureetdecouvertes.com"]
    rules = (
        Rule(
            LinkExtractor(
                allow=(
                    # Specific categories only
                    r"\/jardin\/deco",
                    r"\/jardin\/hamacs",
                    r"\/jardin\/mobilier",
                    r"\/deco-maison\/meuble",
                    r"\/deco-maison\/decoration",
                    r"\/deco-maison\/parfum",
                    r"\/deco-maison\/linge",
                    r"\/deco-maison\/literie",
                    r"\/puericulture\/chambre",
                ),
                deny=(r"\?query="),
                restrict_xpaths=(
                    r"//head",  # link rel="next" for pagination of results
                    r"//*[@class='breadcrumbs__ariane']",  # breadcrumb
                    r"//*[contains(@id,'liste_articles_new2')]",  # product list
                    r"//*[contains(@class,'hamburgerMenu')]",  # left menu
                ),
                tags=("a", "area", "link"),
            ),
            callback="parse_page",
            process_links="exclude_no_follow_links",
            follow=True,
        ),
    )
