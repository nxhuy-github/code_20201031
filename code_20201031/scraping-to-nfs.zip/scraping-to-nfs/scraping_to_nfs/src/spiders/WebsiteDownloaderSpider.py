# -*- coding: utf-8 -*-
from scrapy.spiders import CrawlSpider
from scrapy.loader import ItemLoader
from datetime import datetime
from urllib.parse import urlparse
from base64 import b64encode
from scraping_to_nfs.src.items.WebsiteDownloadItem import WebsiteDownloadItem


class WebsiteDownloaderSpider(CrawlSpider):
    """
    Generic spider class to crawl websites and extract the entire crawl response.

    Parameters
    ----------
    date_ref : str
        date of crawling
    """

    def __init__(self, date_ref, **kwargs):

        self.__date_ref = datetime.strptime(date_ref, "%Y%m%d").strftime("%Y-%m-%d")
        self.__date_crawl = datetime.now().strftime("%Y-%m-%d")
        super(WebsiteDownloaderSpider, self).__init__(**kwargs)

    def parse_page(self, response):
        """
        Methode to scrape items on pages (cf. items.py)     
        
        Parameters
        ----------
        response : scrapy.http.Response
            the HTML response to process.
        
        Returns
        -------
        scrapy.item
            result of scraping
        """

        site_url = "{scheme}://{netloc}".format(
            scheme=urlparse(response.url).scheme, netloc=urlparse(response.url).netloc
        )
        l = ItemLoader(item=WebsiteDownloadItem(), response=response)
        l.add_value("date_ref", self.__date_ref)
        l.add_value("date_crawl", self.__date_crawl)
        l.add_value("site_url", site_url)
        l.add_value("response_url", response.url)
        l.add_value("request_meta", str(response.request.meta))
        l.add_value("response_status", response.status)
        l.add_value("response_meta", str(response.meta))
        l.add_value("response_headers", str(response.headers))
        l.add_value("response_body", b64encode(response.body).decode("utf-8"))
        return l.load_item()

    def parse_start_url(self, response):
        """
        Function to scrape items on start_urls
        
        Parameters
        ----------
        response : scrapy.http.Response
            the HTML response to process.
        
        Returns
        -------
        scrapy.item
            result of scraping
        """

        return self.parse_page(response)

    def exclude_no_follow_links(self, links):
        """
        Function to filter out nofollow link objects from LinkExtractor.
        
        Parameters
        ----------
        links : list
            list of Link objects to filter out.
        
        Returns
        -------
        list
            clean list of links
        """

        ret_links = list()
        if links:
            for link in links:
                link.url = link.url.replace("../", "")
                if not link.nofollow:
                    ret_links.append(link)
        return ret_links
