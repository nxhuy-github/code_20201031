# -*- coding: utf-8 -*-
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scraping_to_nfs.src.spiders.WebsiteDownloaderSpider import WebsiteDownloaderSpider


class WestwingnowFrSpider(WebsiteDownloaderSpider):
    """
    Westwingnow france spider
    
    Parameters
    ----------
    WebsiteDownloaderSpider : class
        Standard Spider
    
    """

    name = "westwingnow_fr"

    # Specific crawling rules for this website
    start_urls = ["https://www.westwingnow.fr"]
    allowed_domains = ["www.westwingnow.fr"]
    rules = (
        Rule(
            LinkExtractor(
                allow=(),
                deny=(
                    r"\?facet",  # Exclude filter selection on category pages
                    r"\?sort",
                    r"\/_.+\/",
                    r"\/~.+\/",
                    r"\/tel:",
                    r"\?simple=",  # Exclude links from product recommendation engine
                ),
                restrict_xpaths=(
                    "//*[@role='navigation']",  # Extract links from header
                    "//*[contains(@class,'pagination')]",  # Extract links from pagination section
                    "//*[contains(@class, 'blockProductGrid')]",  # Extract links from product list
                ),
            ),
            callback="parse_page",
            process_links="exclude_no_follow_links",
            follow=True,
        ),
    )
