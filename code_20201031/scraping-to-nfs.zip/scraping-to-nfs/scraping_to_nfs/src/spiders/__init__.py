"""
Module containing all spider for each website. 

WebsiteDownloaderSpider is the main spider and other spider inherite from it.
"""
